public class FORLOOP {
    public static void main(String[] args) {  
        for(int i=2;i<=15;i++){  
            System.out.println(i);  
        


            for(i=3;i<10;i++){
                System.out.println(i);
            }

          
          }
        }
    }
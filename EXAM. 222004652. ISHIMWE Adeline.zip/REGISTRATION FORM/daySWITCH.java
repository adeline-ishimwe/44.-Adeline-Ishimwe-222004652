public class daySWITCH{
    public static void main(String []args){
    

        int days=4;
        
    
        switch(days){
            case 1:
            System.out.println("x: wet day");
            break;
            case 2:
            System.out.println("x: sunny day");
            break;
            case 3:
            System.out.println("x: cold day" );
            break;
            case 4:
            System.out.println("snowwy day");
            break;
            default: System.out.println("invalid day!");
        
            System.out.println(days);
        }
        }
    }
